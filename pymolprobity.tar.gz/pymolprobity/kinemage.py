'''Kinemage handling for PyMOLProbity plugin.'''

from __future__ import print_function

import logging
import re
from string import digits

import points


logger = logging.getLogger(__name__)



###############################################################################
#
#  COMPILED REGEX
#
###############################################################################

VIEWID_RE = re.compile(
        r'''(\d*)viewid '''     # view number
        r'''{([ \*])'''         # is flipped by Reduce? (* or space)
        r'''([A-Za-z])'''       # single-letter AA resn
        r'''([ \w]{4})'''       # residue number, including insertion code
        r'''([ \w]{2})}''')     # chain id

MASTER_RE = re.compile(r'''master {([^}]*)}''')


###############################################################################
#
#  KINEMAGE
#
###############################################################################

class Kinemage(object):
    '''Store Kinemage data.'''
    def __init__(self):
        self.keywords = {}
        self.dots = []
        self.vectors = []


def single_line_keyword_check(lines):
    if type(lines) is not list:
        msg = 'Expected a list of keyword lines but got: {}'.format(lines)
        raise ValueError(msg)
    if len(lines) > 1:
        logger.warning('  Only using the first line of a multiline keyword!.')


def process_viewid(lines):
    single_line_keyword_check(lines)
    line = lines[0]
    m = VIEWID_RE.match(line)
    if m:
        return {'view_num': (int(m.group(1)) if m.group(1) else 1),
                'flipped': m.group(2) == '*',
                'resn': m.group(3).strip(),
                'resi': m.group(4).strip(),
                'chain': m.group(5).strip(),
                }
    else:
        logger.warning('Unrecognized viewid format: "{}"'.format(line))
        return None


def process_master(lines):
    single_line_keyword_check(lines)
    line = lines[0]
    m = MASTER_RE.match(line)
    if m:
        return m.group(1)



def process_kinemage(kinstr):
    '''Process a Probe output string and return a Kinemage object.'''
    PROCESSED_KEYWORDS = {
            # LISTS
            'dotlist': points.process_dotlist,
            'vectorlist': points.process_vectorlist,

            # VIEWS
            # may be preceded by a number, e.g. `@2viewid`
            'viewid': process_viewid,
            }

    SKIPPED_KEYWORDS = [
            # METADATA
            'text', 'title', 'copyright', 'caption', 'mage', 'prekin',
            'pdbfile', 'command', 'dimensions', 'dimminmax', 'dimscale',
            'dimoffset',

            # DISPLAY OPTIONS
            'whitebackground', 'onewidth', 'thinline', 'perspective', 'flat',
            'listcolordominant', 'lens',

            # MASTERS, ASPECTS, AND COLORS
            'master', 'pointmaster', 'colorset', 'hsvcolor', 'hsvcolour',

            # KINEMAGES, GROUPS, AND SUBGROUPS
            'kinemage', 'group', 'subgroup',

            # LISTS
            'labellist', 'ringlist', 'balllist', 'spherelist', 'trianglelist',
            'ribbonlist', 'marklist', 'arrowlist',

            # VIEWS
            # may be preceded by a number, e.g. `@2span`
            'span', 'zslab', 'center',
            ]

    kin = Kinemage()

    commands = kinstr.lstrip('@').split('\n@')
    for i, command in enumerate(commands):
        lines = command.strip().split("\n")
        keyword = lines[0].split(" ")[0]  # First word after "@"
        base_keyword = keyword.translate(None, digits)  # remove any digits
        if base_keyword in PROCESSED_KEYWORDS.keys():

            # Process with the function listed in PROCESSED_KEYWORDS
            logger.debug('Processing keyword {}: {}...'.format(i, keyword))
            logger.debug("  Processing {}...".format(base_keyword))
            new = PROCESSED_KEYWORDS[base_keyword](lines)
            kin.keywords[i] = {keyword: new}
            logger.debug("  Stored keyword {}: {}.".format(i, keyword))

            # Custom handling for certain keyword types
            if keyword == 'dotlist':
                kin.dots.extend(new)
                logger.debug("  Added dots to Kinemage.")

            elif keyword == 'vectorlist':
                kin.vectors.extend(new)
                logger.debug("  Added vectors to Kinemage.")

            logger.debug("  Finished processing {}.".format(base_keyword))

        elif keyword in SKIPPED_KEYWORDS:
            logger.debug('Skipping keyword {}: {}'.format(i, keyword))

        else:
            logger.warning('Unknown keyword: {}'.format(keyword))

    return kin







