'''Command-line functions for PyMOLProbity plugin.'''

import logging
import subprocess
import tempfile

from pymol import cmd

from settings import mpgetq



# Set up logger
logger = logging.getLogger('mp')



def save_to_tempfile(sel):
    """Save a selection to a temporary PDB file and return the file name."""
    tf = tempfile.NamedTemporaryFile(suffix=".pdb", dir=".")
    fn = tf.name
    tf.close()
    cmd.save(fn, sel)
    return fn


def command_line_output(args, input_str=None):
    """Run a command with the given arguments and optional piped STDIN input
    string, and return STDOUT as a string.

    Also prints the returned output string for `debug_mode` >= 2.
    """
    if input_str is None:
        process = subprocess.Popen(args, stdout=subprocess.PIPE)
        output = process.communicate()[0]
    else:
        assert type(input_str) is str
        process = subprocess.Popen(args,stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        output = process.communicate(input_str)[0]

    logger.debug("===== BEGIN OUTPUT =====\n%s", output)
    logger.debug("===== END OUTPUT =====")

    # error check
    if process.returncode != 0:
        raise Exception('%s returned %s' % (args[0], str(process.returncode)))

    return output


