'''GUI for PyMOLProbity plugin.'''

from Tkinter import *
import Pmw

from pymol import cmd

import main as mp

import logging
logger = logging.getLogger('mp')


class PyMOLProbity:
    """The main PyMOLProbity plugin dialog."""
    def __init__(self, app):
        parent = app.root
        self.parent = parent

        # variables
        self.add_h_input_object = None
        self.flip_input_object = None
        self.probe_input_object = None
        #self.reduce_ready = False  # TODO: check inputs and set these "ready"
        #self.probe_ready = False   #       variables accordingly

        self.dialog = Pmw.Dialog(parent, title="PyMOLProbity", buttons=[])
        self.notebook = Pmw.NoteBook(self.dialog.interior())
        nb = self.notebook
        nb.pack(fill = 'both', expand = 1, padx = 10, pady = 10)

        #main = nb.add('Main')
        #nb.tab('Main').focus_set()



        ### ADD HYDROGENS ###
        self.add_h_page = nb.add('Add Hydrogens')

        # TODO extract input dropdown creation to separate method
        # Input object dropdown
        obj_list = self.object_list()
        if len(obj_list) > 0:
            self.add_h_input_combo = Pmw.ComboBox(self.add_h_page,
                    label_text = 'Input object name:',
                    labelpos = 'w',
                    selectioncommand = self.set_add_h_input_object,
                    scrolledlist_items = obj_list,
            )
            self.add_h_input_combo.pack(fill='x', padx=8, pady=8)

            # select the first object in the list by default
            first = obj_list[0]
            self.add_h_input_combo.selectitem(first)
            self.set_add_h_input_object(first)

        else:
            w = Label(self.add_h_page, text="No objects loaded!")
            w.pack(side='left', fill='x', padx=8, pady=8)

        # Add Hydrogens button
        button = Button(self.add_h_page, text="Add Hydrogens",
            command = self.add_h)
        button.pack(side='top', fill='x', padx=8, pady=8)




        ### REVIEW FLIPS PAGE ###
        # Planned Workflow:
        #  - Select object ("obj")
        #  - Press "Generate Flips"
        #  - Run reduce with recommended flips (program defaults)
        #  - Run reduce with all flips
        #  - Run probe within radius of flip residues for each result.
        #  - load recommended flips into PyMOL object ("mp_obj")
        #  - Display list of flips on the Review Flips page, with zoom buttons,
        #    info about recommendations, and toggle checkboxes to switch
        #    between original and flipped coordinates.

        self.flip_page = nb.add('Check Flips')
        if len(obj_list) > 0:
            self.flip_input_combo = Pmw.ComboBox(self.flip_page,
                    label_text = 'Input object name:',
                    labelpos = 'w',
                    selectioncommand = self.set_flip_input_object,
                    scrolledlist_items = obj_list,
            )
            self.flip_input_combo.pack(fill='x', padx=8, pady=8)

            # select the first object in the list by default
            first = obj_list[0]
            self.flip_input_combo.selectitem(first)
            self.set_flip_input_object(first)

        else:
            w = Label(self.flip_page, text="No objects loaded!")
            w.pack(side='left', fill='x', padx=8, pady=8)

        # Generate Flips button
        button = Button(self.flip_page, text="Generate Flips",
            command = self.generate_flips)
        button.pack(side='top', fill='x', padx=8, pady=8)








        ### PROBE PAGE ###
        probe_page = nb.add('Analyze Contacts')

        # Input object dropdown
        obj_list = self.object_list()
        if len(obj_list) > 0:
            self.probe_input_combo = Pmw.ComboBox(probe_page,
                    label_text = 'Input object name:',
                    labelpos = 'w',
                    selectioncommand = self.set_probe_input_object,
                    scrolledlist_items = obj_list,
            )
            self.probe_input_combo.pack(fill='x', padx=8, pady=8)

            # select the first object in the list by default
            first = obj_list[0]
            self.probe_input_combo.selectitem(first)
            self.set_probe_input_object(first)
        else:
            w = Label(probe_page, text="No objects loaded!")
            w.pack(side='left', fill='x', padx=8, pady=8)

        # Run Probe button
        button = Button(probe_page, text="Run Probe",
            command = self.run_probe_object)
        button.pack(side='top', fill='x', padx=8, pady=8)

        self.notebook.setnaturalsize()



    def object_list(self):
        return cmd.get_names_of_type("object:molecule")

    def update_fields(self):
        obj_list = self.object_list()
        self.add_h_input_combo.setlist(obj_list)
        self.flip_input_combo.setlist(obj_list)
        self.probe_input_combo.setlist(obj_list)

    def set_add_h_input_object(self, obj):
        self.add_h_input_object = obj

    def add_h(self):
        logger.debug('Adding hydrogens for %s...' % self.add_h_input_object)
        mp.add_hydrogens(self.add_h_input_object)
        logger.debug('Finished adding hydrogens.')
        self.update_fields()
        # TODO: go to next page  #self.next_page()



    def set_flip_input_object(self, obj):
        self.flip_input_object = obj

    def display_flips_list(self, flip_list):
        """Display the flips list in an area on the Flips page."""
        assert type(flip_list) is list
        assert type(flip_list[0]) is mp.Flip

        # Flip group
        self.flip_group = Pmw.Group(self.flip_page, tag_text="Choose Flips")
        self.flip_group.pack(fill = 'both', expand = 1, padx = 6, pady = 6)

        parent = self.flip_group.interior()

        for i, f in enumerate(flip_list):

            chk = Pmw.RadioSelect(parent,
                    buttontype='checkbutton',
                    command=self.flip_checkbutton_callback)
            chk.add(str(i))
            chk.grid(row=i, column=0)

            if not f.code:
                logger.debug('disabling checkbutton %i' % i)
                chk.button(str(i)).configure(state='disabled')


            # Check if flip is recommended
            if f.code == 'F':
                chk.invoke(str(i))

            # Atom selection
            lbl = Label(parent, text=f.macro)
            lbl.grid(row=i, column=1)

            # Zoom button
            button = Button(parent,
                    text="Zoom",
                    command = f.zoom)
            button.grid(row=i, column=2)


    def get_flips_list(self, obj):
        """Return a list of flips and selections for zooming."""
        o = mp.get_object(obj)
        return o.flips



    def generate_flips(self):
        logger.debug("Begin generate_flips()...")
        # create Flip() records from Reduce PDBs if not already there
        mp.generate_flips(self.flip_input_object)
        flip_list = self.get_flips_list(self.flip_input_object)
        self.display_flips_list(flip_list)
        self.notebook.setnaturalsize()
        #self.update_fields()
        logger.debug("End generate_flips().")

    def flip_checkbutton_callback(self, tag, state):
        if state:
            logger.debug("Button for flip %s was checked." % tag)
            mp.load_flipped_coords_for_flip(self.flip_input_object, int(tag))
        else:
            logger.debug("Button for flip %s was unchecked." % tag)
            mp.load_unflipped_coords_for_flip(self.flip_input_object, int(tag))
        logger.debug("Finished with flip %s checkbutton callback." % tag)



    def set_probe_input_object(self, obj):
        self.probe_input_object = obj

    def run_probe_object(self):
        mp.generate_kinemage(self.probe_input_object)
        self.update_fields()



