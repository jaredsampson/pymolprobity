''' Utility functions for PyMOLProbity plugin. '''


def quote_str(var, quote="'"):
    '''Enclose a str variable in quotes for printing.'''
    if type(var) is str:
        return '%s%s%s' % (quote, var, quote)
    else:
        return var


def to_number(var):
    '''Convert a variable to a number if possible, and return it.

    Convert the passed variable to a number if possible and return the
    number.  Otherwise, return the original variable.
    '''
    try:
        var = int(str(var))
    except:
        # fallback to float
        try:
            var = float(str(var))
        except:
            pass # default to leave as-is
    return var

