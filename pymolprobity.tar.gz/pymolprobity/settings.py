'''Settings for PyMOLProbity plugin.'''

import logging

from pymol import cmd, plugins

import utils


# Set up logger
logger = logging.getLogger('mp')


MP_DEFAULT_SETTINGS = {
        'debug_level': 0,
        'dot_mode': 0,
        'dot_radius': 0.03,
        'prefix': 'mp_',
        'probe_path': 'probe',
        'reduce_path': 'reduce',
        }


MP_SETTINGS = MP_DEFAULT_SETTINGS.copy()


def set_logging_level(logger, debug_level):
    """Set the logging level based on the desired debug_level."""
    logger.debug("Begin `set_logging_level`...")
    debug_level = int(debug_level)
    assert debug_level in range(0,3)
    levels = {0: logging.WARNING,
              1: logging.INFO,
              2: logging.DEBUG}
    logger.setLevel(levels[debug_level])
    logger.info('Set logging level to %s.' % levels[debug_level])
    logger.debug("End `set_logging_level`.")


def load_settings():
    """Load saved MolProbity plugin-specific settings.

    Use plugins.pref_get to read MolProbity plugin-specific settings stored in
    ~/.pymolpluginsrc.py by the Plugin Manager.
    """
    settings = {}
    for s in MP_DEFAULT_SETTINGS:
        # read from .pymolpluginsrc.py
        # if not found, equivalent to `self.s = None`
        settings[s] = plugins.pref_get('molprobity.%s' % s)
        # fill in default value if necessary
        if settings[s] is None:
            msg = "  Custom setting %s not found...using default value" % s
            logger.info(msg)
            settings[s] = MP_DEFAULT_SETTINGS[s]
        if s == 'debug_level':
            set_logging_level(logger, settings[s])
    if len(settings.items()) > 0:
        logger.info(
                "Read MolProbity plugin settings from ~/.pymolpluginsrc.py.")
        MP_SETTINGS = settings.copy()
    else:
        logger.warning("Unable to load MolProbity settings.")


def reset_default_settings(quiet=0):
    """Reset the default settings for the MolProbity plugin."""
    MP_SETTINGS = MP_DEFAULT_SETTINGS.copy()
    if not quiet:
        logger.info("Reset MolProbity plugin settings to default values.")


def save_settings():
    """Save the current MolProbity plugin settings.

    Use plugins.pref_set to save MolProbity plugin-specific settings to
    ~/.pymolpluginsrc.py.
    """
    for s in MP_SETTINGS:
        # Note: Any changes to MP_SETTINGS keys during the session may result
        # in improperly saved settings.
        plugins.pref_set('molprobity.%s' % s, MP_SETTINGS[s])
    logger.info("Saved MolProbity plugin settings to ~/.pymolpluginsrc.py")


def mpset(setting, value, quiet=0):
    """Set the specified MolProbity plugin setting."""
    value = utils.to_number(value)
    try:
        MP_SETTINGS[setting] = value
    except:
        logger.warning("mpset: Unable to set %s to %s." % (setting,
            utils.quote_str(value)))
        return -1

    if setting == 'debug_level':
        set_logging_level(logger, value)

    msg = "mpset: %s set to %s." % (setting, utils.quote_str(value))
    logger.debug(msg)

    if not quiet:
        print msg

    return 0


def mpget(setting, quiet=0):
    """Return the value of the specified MolProbity plugin setting."""
    try:
        s = MP_SETTINGS[setting]
    except:
        logger.warning("mpget: Unable to read %s setting." % setting)
        return None

    msg = "mpget: %s = %s" % (setting, utils.quote_str(s))

    if not quiet:
        print msg

    return s


def mpgetq(setting):
    """Return the value of the specified MolProbity plugin setting quietly."""
    return mpget(setting, quiet=1)



cmd.extend('mp_load_settings', load_settings)
cmd.extend('mp_save_settings', save_settings)
cmd.extend('mp_reset_default_settings', reset_default_settings)
cmd.extend('mpset', mpset)
cmd.extend('mpget', mpget)

