'''Main functions for PyMOLProbity plugin.'''

from __future__ import print_function

import logging
import os
# import re
import subprocess
import tempfile

from pymol import cmd  #cgo, cmd, plugins

# import colors
# from commands import command_line_output, save_to_tempfile
import flips
import kinemage
import points
# import settings
# import utils


# Set up logger
logging.basicConfig(level=logging.INFO)  # TODO change to WARNING for release
logger = logging.getLogger(__name__)


# # Load saved settings from ~/.pymolpluginsrc if available
# settings.load_settings()



###############################################################################
#
#  MPOBJECT
#
###############################################################################

class MPObject(object):
#     """Storage class for MP data associated with a loaded PyMOL object."""

#     def get_data_group_name(self):
#         return "%s._data" % self.mpname

#     def get_data_object_name(self, i):
#         suffixes = ['noflips', 'flips', 'allflips']
#         return "%s.%s_%s" % (self.get_data_group_name(), self.name, suffixes[i])

    def get_dots_cgo(self, dot_mode=0):  # TODO combine with .get_vectors_cgo()
        cgolist = []
        for dot in self.dots:
            cgolist.extend(dot.get_cgo(dot_mode))
        return cgolist

    def get_vectors_cgo(self):
        cgolist = []
        for vector in self.vectors:
            cgolist.extend(vector.get_cgo())
        return cgolist

    def draw(self, dot_mode=0):
        '''Draw the visualization of Probe output for the object.'''
        logger.debug('Drawing Probe results...')
        view = cmd.get_view()

        # Speed up CGO sphere rendering
        if dot_mode == 0:
            cmd.set('cgo_use_shader', 0)
            cmd.set('cgo_sphere_quality', 0)

        # Get CGO lists
        dots_cgo = self.get_dots_cgo(dot_mode=dot_mode)
        vectors_cgo = self.get_vectors_cgo()

        # Write to objects
        dots_obj = '{}_dots'.format(self.name)
        vectors_obj = '{}_clashes'.format(self.name)
        cmd.load_cgo(dots_cgo, dots_obj)
        cmd.load_cgo(vectors_cgo, vectors_obj)

        # Group objects with mp results
        cmd.group('mp_{}'.format(self.name), dots_obj)
        cmd.group('mp_{}'.format(self.name), vectors_obj)

        # restore initial view
        cmd.set_view(view)
        logger.debug('Finished drawing ProbeResult.')

    def get_pdbstr(self):
        # TODO this needs some work
        nameFH = '{}FH'.format(self.name)
        nameH = '{}H'.format(self.name)
        if nameFH in cmd.get_names():
            return cmd.get_pdbstr(nameFH)
        elif nameH in cmd.get_names():
            return cmd.get_pdbstr(nameH)
        else:
            msg = 'Sorry, no object loaded called {} or {}!'.format(nameFH,
                    nameH)
            logger.warning(msg)
            return None

    def __init__(self, name):
        self.name = name
        # self.mpname = "%s%s" % (settings.mpgetq('prefix'), self.name)
        # self.rname = "reduce_%s" % self.name
        # self.pname = "probe_%s" % self.name
        # self.robj = "%s.%s" % (self.mpname, self.rname)
        # self.pobj = "%s.%s" % (self.mpname, self.pname)

        # Loaded object names
        self.pdb = None
        self.kin = None

        # Reduce output
        self.flips = None

        # Flipkin output
        # self.flipkin_nq = None
        # self.flipkin_h = None
        # self.multikin = None

        # Probe output
        self.dots = None
        self.clashes = None

#     def __str__(self):
#         return "<MPObject: %s>" % self.name


# ###############################################################################
# #
# #  GENERAL FUNCTIONS
# #
# ###############################################################################

def get_object(obj):
    '''Return the matching MPObject instance, if it exists.

    ARGUMENTS
        obj     can be either a string (object name) or MPObject instance

    '''
    if type(obj) is str:
        try:
            return objects[obj]
        except:
            msg = "get_object: '{}' not in plugin objects dict.".format(obj)
            raise AttributeError, msg
    elif type(obj) is MPObject:
        try:
            assert obj.name in objects.keys()
            assert obj in objects.values()
            return obj
        except:
            msg = "get_object: '{}' not in plugin objects dict.".format(obj)
            raise AttributeError, msg
    else:
        msg = "get_object: `obj` must be either a string or MPObject instance."
        raise ValueError, msg


def get_or_create_object(obj):
    '''Return the matching MPObject instance if it exists, or create it.

    ARGUMENTS
        obj     [string] object name

    '''
    # Check input
    msg = "get_or_create_object: `obj` must be a string"
    if not type(obj) is str: raise TypeError, msg

    # Get the object...
    try:
        return get_object(obj)
    # Or create it
    except AttributeError:
        objects[obj] = MPObject(obj)
        return get_object(obj)


def save_to_tempfile(data_str):
    """Save a selection to a temporary PDB file and return the file name."""
    tf = tempfile.NamedTemporaryFile(suffix=".pdb", dir=".", delete=False)
    tf.write(data_str)
    tf.close()
    return tf.name


def run_command(args, input_str=None):
    """Run a command with the given arguments and optional piped STDIN input
    string, and return STDOUT as a string.
    """
    if input_str is None:
        process = subprocess.Popen(args, stdout=subprocess.PIPE)
        output = process.communicate()[0]
    else:
        assert type(input_str) is str
        process = subprocess.Popen(args,stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        output = process.communicate(input_str)[0]

    logger.debug("===== BEGIN OUTPUT =====\n%s", output)
    logger.debug("===== END OUTPUT =====")

    # Error check
    if process.returncode != 0:
        raise Exception('%s returned %s' % (args[0], str(process.returncode)))

    return output


###############################################################################
#
#  REDUCE
#
###############################################################################

def get_reduce_args(h=1, flip=1, quiet=1, addflags=None):
    """Return a list of arguments to be used to run Reduce locally.

    Prepare arguments to run Reduce locally using the specified options.  Note
    that the path to the `reduce` executable must be set in the MolProbity
    plugin settings (see [mpset], [mpget]).

    With no keyword arguments, uses Reduce defaults, to perform NQH flips and
    add hydrogens.

    Any additional options passed via `addflags` will take precedence over
    other options specified by the normal keyword arguments.

    USAGE:

        get_reduce_args [h=1, [flip=1, [quiet=1, [addflags=None]]]]

    ARGUMENTS:

        h:
            1 = Add hydrogens.  (default)
            0 = Remove ("trim") hydrogens if present.

        flip:
            If unset, no NQH flips will be performed.  (default=1)

        quiet:
            Suppress reduce's normal console output.  (default=1)

        addflags:
            A space-separated string of additional flags to pass directly to
            Reduce (e.g.  "-DENSITY24 -SHOWSCORE").  (default=None)

    """
    # Check inputs
    msg = "get_reduce_args: `{}` must be of type (or castable as) `{}`"
    try: h = int(h)
    except: raise TypeError(msg.format('h', int))
    try: flip = int(flip)
    except: raise TypeError(msg.format('flip', int))
    try: quiet = int(quiet)
    except: raise TypeError(msg.format('quiet', int))

    # Handle nonbinary values
    if h     != 0:  h     = 1
    if flip  != 0:  flip  = 1
    if quiet != 0:  quiet = 1

    if addflags is not None:
        if type(addflags) is not str:
            msg = ("get_reduce_args: `addflags` should be a space-separated "
                   "string of options to pass to Reduce.")
            raise TypeError(msg)
#     logger.debug('reduce_object inputs are ok.')

    # Begin with the path to `reduce`.
    args = ['reduce']  # [settings.mpgetq('reduce_path')]

    # Handle keyword arguments
    if quiet:
        args.append('-Quiet')

    if flip:
        args.append('-FLIP')
    else:
        args.append('-NOFLIP')

    if h == 0:
        args.append('-Trim')

    # Any user-specified flags are added last.  These will take precedence over
    # any of the previous flags from keyword arguments.
    if addflags:
        args.extend(addflags.split(' '))

    # Pass the pdbstr from STDIN
    args.append('-')

    return args


def generate_reduce_output(pdbstr, flip_type=1):
    '''Generate Reduce output from the given PDB string and flip_type.

    ARGUMENTS
        pdbstr (str)    A loaded PyMOL object (typically an automatically
                        generated temporary one, without hydrogens).

        flip_type (int) Indicates which type of result to make.
                        0 = no flips
                        1 = recommended flips (default)
                        2 = all flips

    '''
    lookup = {
            0: {'flip': 0},               # no flips
            1: {},                        # default flips
            2: {'addflags': '-NOBUILD0'}  # all scorable flips
            }
    args = get_reduce_args(**lookup[flip_type])
    output = run_command(args, pdbstr)
    return output


def process_reduce_output(reduced_pdbstr):
    '''Process Reduce output and return a Reduce result dict.'''
    prefix = 'USER  MOD '
    if not type(reduced_pdbstr) is str:
        msg = 'process_reduce_output: argument `reduced_pdbstr` must be a string.'
        raise TypeError(msg)
    if not reduced_pdbstr.startswith(prefix):
        raise ValueError('process_reduce_output: malformed input string')
    lines = reduced_pdbstr.split('\n')

    # Collect USER MOD records and remove the prefix from each line.
    user_mod = [l.replace(prefix, '') for l in lines if prefix in l]

    flips_list = flips.parse_flips(user_mod)

    return flips_list


def reduce_object(obj, flip=1):
    """Add hydrogens to a copy of a loaded PyMOL object with Reduce.

    TODO: more doc here

    """
    # Run reduce with specified flips
    pdbstr = cmd.get_pdbstr(obj)
    reduced_pdbstr = generate_reduce_output(pdbstr, flip_type=flip)
    withflips = " with flips" if flip else ""
    logger.info("Generated Reduce output{} for '{}'.".format(withflips, obj))

    # Process the output string for flips
    flips_list = process_reduce_output(reduced_pdbstr)
    logger.info("Processed Reduce output to extract list of flips.")

    # Store flips list and raw reduced_pdbstr in MPObject
    o = get_or_create_object(obj)
    o.flips = flips_list

    # Create a group for MP results
    prefix = 'mp_'  # TODO read from settings
    group_name = '{}{}'.format(prefix, obj)
    cmd.group(group_name)

    # Load the output PDB into a copy of the original, put it into the group,
    # and disable the original object.
    suffix = 'FH' if flip else 'H'
    name = '{}{}'.format(obj, suffix)
    cmd.create(name, obj)  # duplicate original to preserve representation
    cmd.disable(obj)
    cmd.read_pdbstr(reduced_pdbstr, name, state=1)
    cmd.group(group_name, name)



###############################################################################
#
#  FLIPKIN
#
###############################################################################

def generate_flipkin_output(filename, his=False):
    flipkin_path = 'flipkin'  # TODO settings
    args = [flipkin_path]
    if his:
        args.append('-h')
    args.append(filename)
    output = run_command(args)
    return output


def process_flipkin_output(flipkin):
    '''Parse a flipkin kinemage and return a list of flippable residues.'''
    kin = kinemage.process_kinemage(kinstr)
    # TODO Get list of flippable residues
    # TODO Collect unflipped and flipped coordinates of flippable residues
    # TODO Collect unflipped and flipped dots and vectors associated with them
    # TODO Assemble the coordinates, dots, and vectors into a list of flips.

def create_multikin(proc_nq, proc_h):
    pass


def flipkin_object(obj):
    '''Run flipkin to generate Asn/Gln and His flip kinemages.

    ARGUMENTS

        obj (str)

            Name of a loaded PyMOL object that has already been passed as an
            argument to `reduce_object()` (`reduce_obj` from the PyMOL command
            line).

    Uses the coordinates output from a previous run of reduce_object().
    '''
    o = get_object(obj)

    # Save a tempfile
    pdbstr = o.get_pdbstr()
    tf = save_to_tempfile(pdbstr)

    # Run flipkin to get NQ and H flip kinemages
    o.flipkin_nq = generate_flipkin_output(tf)
    o.flipkin_h = generate_flipkin_output(tf, his=True)

    # Cleanup
    os.unlink(tf)

    # Process flipkins
    flip_nq = process_flipkin_output(o.flipkin_nq)
    flip_h = process_flipkin_output(o.flipkin_h)

    # Create multikin
    o.multikin = create_multikin(flip_nq, flip_h)

    logger.info("Generated Flipkin output for '{}'.".format(obj))




###############################################################################
#
#  PROBE
#
###############################################################################

def get_probe_args(pdb_file):
    '''Return arguments for running Probe on the given the PDB filename.'''
    probe_path = 'probe'  # TODO settings.mpgetq('probe_path')
    return [probe_path, '-Quiet', '-Self', 'ALL', pdb_file]


def generate_probe_output(pdbstr):
    '''Generate Probe output from the given PDB string.

    ARGUMENTS
        pdbstr (str)    PDB coordinates from a loaded PyMOL object.

    '''
    # Probe doesn't accept input via STDIN, so we need to write a tempfile.
    tf = save_to_tempfile(pdbstr)
    assert os.path.isfile(tf)
    args = get_probe_args(tf)
    output = run_command(args)
    os.unlink(tf)
    assert not os.path.isfile(tf)
    return output


def process_probe_output(kinstr):
    '''Process Probe output and return lists of dots and clashes.'''

    kin = kinemage.process_kinemage(kinstr)
    return kin.dots, kin.vectors


def probe_object(obj):
    '''Run Probe on the "Reduce-d" coordinates of a loaded PyMOL object.

    ARGUMENTS

        obj (str)

            Name of a loaded PyMOL object that has already been passed as an
            argument to `reduce_object()` (or `reduce_obj` from the PyMOL
            command line).

    NOTE

        Reduce_object() must be run prior to probe_object() in order to set up
        an MPObject instance in the `objects` dictionary.  Running
        probe_object() on a plain PyMOL object will fail.  Also, accordingly,
        keep in mind that the coordinates probe_object() uses are those of the
        Reduce-modified version.  For an object `myobj`, this will typically
        be `myobjFH` within group `mp_myobj`.

    '''


    o = get_object(obj)
    pdbstr = o.get_pdbstr()
    o.kin = generate_probe_output(pdbstr)
    logger.info("Generated Probe output for '{}'.".format(obj))

    # Store list of dots and vectors
    o.dots, o.vectors = process_probe_output(o.kin)

    # Draw dots and vectors
    o.draw()








# def generate_flips(obj, overwrite=0):
#     o = get_object(obj)
#     if (len(o.flips) == 0) or overwrite:
#         if len(o.flips) != 0 and overwrite:
#             logger.warning("%s: overwriting existing flips!" % obj)
#         logger.debug("%s: generating flips..." % obj)
#         o.generate_flips()
#     else:
#         # Flips from different runs of Reduce should generally be the same
#         # for a given set of coordinates, though the recommended/output
#         # flip state may be different depending on Reduce arguments.
#         logger.debug("%s: flips already present." % obj)


# def load_flip_coords(obj, flip_index, result_index):
#     """Return coordinates for selection indicated by the specified Flip.

#     PARAMETERS
#     obj = (str) name of object
#     flip_index = (int) flip index
#     result_index = (int) result index (possible values 0, 1, or 2)
#     """
#     assert type(flip_index) is int
#     assert type(result_index) is int
#     assert result_index in range(0, 3)
#     logger.debug('load_flip_coords inputs are ok.')

#     o = get_object(obj)
#     r = o.get_rr(result_index)
#     f = o.flips[flip_index]

#     # Get a selection for f atoms in the displayed object (robj)
#     f_sel = f.get_selection()
#     source_sel = "%s and %s" % (o.get_data_object_name(result_index), f_sel)
#     target_sel = "%s and %s" % (o.robj, f_sel)
#     logger.debug('source sel: %s' % source_sel)
#     logger.debug('target sel: %s' % target_sel)

#     source_coords = cmd.get_coords(source_sel)
#     target_coords = cmd.get_coords(target_sel)
#     logger.debug('source coords: %s' % source_coords)
#     logger.debug('target coords: %s' % target_coords)
#     assert len(source_coords) == len(target_coords)

#     logger.debug('Actually loading new coordinates for %s flip %i...\n' %
#             (obj, flip_index))
#     cmd.load_coords(source_coords, target_sel)
#     logger.debug('Finished loading coordinates.')


# def load_flipped_coords_for_flip(obj, i):
#     """Load the flipped coordinates for MPObject `obj` Flip at index `i`."""
#     logger.debug("Loading flipped coordinates for %s flip #%i..." % (obj, i))
#     o = get_object(obj)
#     f = o.flips[i]
#     if f.clique == 'single':
#         logger.debug('starting single flip %i' % i)
#         load_flip_coords(obj, i, 2)
#         logger.debug('finished single flip %i' % i)
#     elif f.clique == 'set':
#         logger.debug('starting flip set #%i' % f.set_number)
#         for x, y in enumerate(o.flips):
#             if y.set_number == f.set_number:
#                 if y.clique == 'set':
#                     load_flip_coords(obj, x, 2)
#                     # CONTINUE HERE
#         logger.debug('finished flip set #%i' % f.set_number)
#     logger.debug("...done.")


# def load_unflipped_coords_for_flip(obj, i):
#     """Load the unflipped coordinates for MPObject `obj` Flip at index `i`."""
#     logger.debug("Loading unflipped coordinates for %s flip #%i..." % (obj, i))
#     load_flip_coords(obj, i, 0)
#     logger.debug("...done.")




# Set up a module-level `objects` storage variable the first time only.
try:  # pragma: no cover
    len(objects)
    logger.info('Using existing MolProbity objects list.')
except:
    objects = {}
    logger.info('Set up MolProbity objects list.')



# ###############################################################################
# #
# #  Set up CLI
# #
# ###############################################################################

cmd.extend('reduce_obj', reduce_object)
cmd.extend('probe_obj', probe_object)

logger.info('Finished loading MolProbity plugin.')
